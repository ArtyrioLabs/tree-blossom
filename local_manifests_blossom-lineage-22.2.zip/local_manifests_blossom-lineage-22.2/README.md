<h1 align="center" id="title">Local_Manifests_Blossom</h1>
<p align="center" id="description">Local_Manifests for LineageOS-22.2 </p>

```
git clone https://github.com/AsTechpro20/local_manifests_blossom.git -b lineage-22.2 .repo/local_manifests
```

